var penColour ='black';

function setPenColour(pen)
{
	penColour = pen;
}
function setPixelColour(pixel)
{
	pixel.style.backgroundColor = penColour;
}

