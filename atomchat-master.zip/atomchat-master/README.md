# PHP Atomchat

**PHP Atomchat** is a **free PHP chat script** for low volume sites or individual homepages, e.g. P2P chat.

- Works OOTB
- Completely anonymous
- No registration or passwords ever
- Emoji auto-conversion
- File uploads
- Multi-lingual
- No database required
